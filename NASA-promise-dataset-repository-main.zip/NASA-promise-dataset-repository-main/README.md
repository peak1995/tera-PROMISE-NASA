# NASA-promise-dataset-repository
This repository contains 5 datasets, namely, KC1, JM1, CM1, KC2, PC1 in CSV and ARFF formats. 
These datasets are used to train Software Defect Prediction Models.
All these datasets are obtained from the NASA promise dataset repository.

Link to the data repository - http://promise.site.uottawa.ca/SERepository/datasets-page.html
